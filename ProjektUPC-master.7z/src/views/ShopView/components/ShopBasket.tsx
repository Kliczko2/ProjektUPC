import { Drawer } from 'antd'
import React, { useState } from 'react'
import { ShoppingCartOutlined } from '@ant-design/icons'

const ShopBasket: React.FC = () => {
  const [shopBasketOpen, setShopBasketOpen] = useState<boolean>(false)
  return (
    <>
      <div
        onClick={() => {
          setShopBasketOpen(true)
        }}
      >
        <ShoppingCartOutlined />
      </div>
      <div>
        <Drawer
          open={shopBasketOpen}
          onClose={() => {
            setShopBasketOpen(false)
          }}
        ></Drawer>
      </div>
    </>
  )
}
export default ShopBasket
