import React from "react";
import './About.css'

function About(){
    return(
       <section className="about">
            
            <div className="main">
                <img src="https://ocdn.eu/pulscms-transforms/1/CjTk9kpTURBXy8yMzQxNmI1OTlhZTI1ZmJlODcxN2QyYjgyYzNhMmNjZi5wbmeTlQMALc0FoM0DKpUCzQSwAMPDkwmmZDRlMzhmBt4AAaEwAQ/blanka.jpeg"></img>
                <div className="about-text">
                <h1>Polski talent</h1>
                    <p>Baby
It's kind of crazy
How else to phrase it?
With you I've lost my senses
Baby
What happened to ya?
I thought I knew ya
But now it's time to face it
You're hot and cold
High and you're low
Messin' with my mind
No, oh-oh, that's not how it goes
So, let me spell it out
Now I'm better solo, solo
I never let me down, didi-down-down-down
Now I'm gonna show ya, show ya
Show you what it is you're missing out
Now I'm better solo, solo
I never let me down, didi-down-down-down
Now I'm gonna show ya, show ya
How I be getting down, solo
Tell me
Now, was it worth it? (Oh)
Playin' me dirty (oh)
But now who's laughing, baby?
</p>
                </div>
            </div>
            
            
        </section> 
    )
}
export default About