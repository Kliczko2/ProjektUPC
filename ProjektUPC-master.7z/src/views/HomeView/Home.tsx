import React from "react";
import './Home.css'
function Home(){
    return(
        <div className="home">
            <h1 className="title">Home</h1>
        </div>
    )
}
export default Home